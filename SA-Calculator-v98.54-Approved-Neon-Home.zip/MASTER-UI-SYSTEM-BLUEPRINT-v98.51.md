# SA Calculator — Master UI & System Blueprint v98.51

## 0. Scope and source truth
This blueprint is based on the v98.50 source package, its actual screen DOM, event handlers, current 17-card tool catalogue, Settings controls, history persistence, on-demand keypad and the supplied Basic/Scientific reference screenshots. It is not a claim that missing engines already exist. All dimensions below are responsive design targets in dp/CSS px equivalents; final rendered geometry must be verified on physical devices at compact, medium and expanded window sizes.

## 1. Global shell and navigation

### 1.1 App shell
- Preserve Android status and system navigation bars. Do not draw fake status icons or replace OS navigation.
- Remove the redundant global in-app header on calculator and individual tool screens; use one contextual tool toolbar only when inside a secondary screen.
- The workspace occupies the remaining height between OS insets and the bottom app navigation. Only the active screen is focusable (`inert`/`aria-hidden` for inactive screens).
- No screen may place a fixed control over a keypad, result, or active form field. Scroll the content pane independently; keep toolbar and bottom navigation stable where shown.
- Respect safe-area insets, keyboard resize, orientation changes, reduced motion and font scaling.

### 1.2 Primary navigation — five equal destinations
| Order | Destination | Content | Selection behavior |
|---|---|---|---|
| 1 | Calculator | Basic calculator home | Returns to calculator without clearing expression |
| 2 | History | Calculation history overlay/page surface | Shows newest first; restore/copy/share/name/protect/delete; clear only unlocked rows |
| 3 | Favorites | User-pinned calculator/tool shortcuts | Opens the selected tool; empty state links to Settings/Favorites |
| 4 | Tools | Search + category-filtered tool catalogue | Opens one selected tool; search/category state should persist while returning |
| 5 | Settings | All preferences | Opens Settings; changes persist immediately and are reflected on all screens |

Target: 5 equal columns; 76dp nominal height plus safe-area handling; icon 20–22dp; label 11–12sp; active pill background; each hit target at least 48×48dp. On short-height windows, compact to 66dp while retaining hit target and label legibility. On widths ≥600dp, use a wider navigation treatment only if the app actually adopts a rail; do not stretch phone-sized buttons.

### 1.3 Individual tool navigation
- Hide primary bottom navigation for every individual tool, including Scientific Calculator, converters, Finance and Daily tools.
- A single 56dp contextual toolbar: Back (44–48dp hit area), centered single-line title, right action only when it has a real action. Do not label a Tools navigation action as “More options”.
- Back returns to the actual previous top-level screen, not always Calculator; preserve field values, selected units/currencies, scroll position and Tools search/filter context. Close the transient numeric keypad on navigation and restore focus to the originating screen.
- Android system Back and toolbar Back must call the same navigation stack handler. Escape closes picker/dialog/keypad before leaving a screen.

## 2. Design tokens and layout rules

| Token | Target |
|---|---:|
| Phone content side inset | 12–16dp |
| Card inset | 12–16dp |
| Tight gap | 4dp |
| Standard gap | 8dp |
| Section gap | 16–20dp |
| Context toolbar | 56dp (50dp compact-height fallback) |
| Standard input | 52–56dp; never below 48dp interactive height |
| Primary action | 50–52dp |
| Card radius | 14–16dp |
| Control radius | 10–12dp |
| Dialog radius | 16–20dp |
| Section label | 11–12sp, medium/bold, letter spacing |
| Field label | 12–13sp |
| Main value | 18–24sp, content-fit |
| Body text | 13–14sp |
| Touch target | ≥48×48dp; visible glyph may be smaller but hit area must not shrink |

Use window size classes rather than device names: compact width <600dp; medium 600–839dp; expanded ≥840dp. For compact phones, two-column Tools cards; medium 3 columns; expanded use a bounded content width or pane layout rather than stretching every control. Compact-height/landscape must prioritize visible keypad and allow display/result to shrink without clipping.

## 3. Calculator home — Basic

### 3.1 Placement
1. Expression/display region at top; expression aligned to logical end, result preview beneath it.
2. Keypad fills remaining usable height; no extra in-app header above display.
3. 4-column, 5-row keypad. Row 1: AC, +/−, %, ÷. Rows 2–4: 7–9/×, 4–6/−, 1–3/+. Final row: 0 spans two columns, decimal, equals.
4. Keep operators in a stable right column. Zero is exactly double-width, not a manually oversized neighboring key.

### 3.2 Sizing/appearance
- Equal cell widths; 4–6dp visual gap; 12–18dp corner radius; 48dp minimum hit height.
- On tall phones, use the available vertical space to enlarge key faces evenly; on short screens, reduce display height and gap before reducing the 48dp touch floor.
- Numeric labels 24–28sp; operators 23–27sp; utility labels 18–22sp; AC 18–22sp.
- Blue primary action keys (AC and operators/equal according to the approved theme), neutral deep-navy numeric keys, consistent contrast in every theme.

### 3.3 Behavior
- Live preview never commits history. Equals commits exactly once; repeated equals follows the existing repeat-operation policy.
- AC clears expression/result/preview; delete removes one logical token; +/- changes the active operand; percent follows contextual percentage rules.
- Preserve caret and selection when inserting keypad tokens. Keyboard input and touch keypad must use the same parser and error path.
- Result formatting obeys precision/grouping/trailing-zero preferences; never silently truncate precision used by the calculation engine.

## 4. Scientific Calculator

### 4.1 Screen geometry
- Dedicated screen, independent state and memory from Basic.
- Display 20–25% of usable height (minimum 140dp; compact-height target 118–132dp); top status row includes DEG/RAD and memory status, History and More actions.
- Expression line 22–30sp, left-aligned; result 28–40sp, right-aligned; long expression scrolls horizontally with caret preserved. Display must not clip radicals, fractions or exponent tokens.
- Editing strip: 6 equal controls — SHIFT, DRG, left, right, delete, AC. 48dp target.
- Function bank: 6 equal columns; each key 48–54dp high with primary function centered and a 9–11sp secondary legend above it. Gold legend, graphite beveled key. SHIFT visibly latches and shows active state; tap a mapped key once to consume SHIFT.
- Memory row: 5 equal controls (D°M′S, fraction/convert where supported, X/Y/M, MR, x→M according to current mapping), minimum 44–48dp target.
- Numeric/operator bank: 5 columns × 4 rows matching the supplied reference: 7 8 9 ( ); 4 5 6 × ÷; 1 2 3 + −; 0 . +/− EXP =. Numeric keys 50–54dp where height permits; operator keys visually distinct without changing grid geometry.
- More panel holds only functions actually implemented and tested; scrolls independently and closes after selection. History panel is separate from More.

### 4.2 Functional mapping and invariants
- SHIFT alternate labels must match the actual insertion/action handler; no decorative legend without a working mapping.
- DEG/RAD mode is explicit, persisted, reflected in the status indicator and applied consistently to trig/inverse-trig.
- Constants, trig/inverse trig, hyperbolic trig, powers/roots, logs, factorial, abs, scientific exponent, parentheses, fractions (only if engine supports), memory, ANS and history require domain/edge-case tests.
- Memory (M+, M−, MR, clear/store) is independent from Basic memory and survives restart when storage is available.
- Complex numbers, matrices, symbolic algebra, calculus/integrals/derivatives, graphing and programmer bases are not advertised as active until their own engines, input UX, result formatting and test suites are shipped.

## 5. Tools catalogue

### 5.1 Tools landing screen
- Header title “Tools”; search field first (48dp), horizontally scrollable category chips next (36–40dp), then cards.
- Categories: All, Finance, Math, Convert, Daily. Preserve category/search state when navigating into a tool and back.
- Cards: 2 columns compact; 3 medium; bounded grid expanded. Each card 72–84dp tall; 36–42dp icon tile; two-line title max; arrow aligned to end. No clipped names or overlapping search/chips.
- Search matches tool name, aliases and category; empty state provides clear-search action.

### 5.2 Tool screen common contract
- Toolbar is the only top-level header; content begins directly below it.
- Form fields use 52–56dp rows; labels 12–13sp; numeric value aligned consistently; card sections use 12–16dp padding and 8–12dp vertical gaps.
- One shared numeric keypad sheet for numeric inputs: 4×4, 52dp keys, 8dp gap, 7–8–9/delete, 4–5–6/Next, 1–2–3/Clear, 0/00/decimal/Done. It follows the active field and never covers the toolbar or result. Only fields that accept numbers open it.
- Use a native date picker and native time controls for dates and time, searchable selection dialogs for long lists, and the correct specialized keyboard for base conversion.
- Recalculate on valid input changes; show neutral incomplete state, clear validation errors beside the relevant field, and result only when inputs are sufficient. Never show stale results after inputs change.

### 5.3 Exact tool-by-tool placement and behavior
| Tool | Screen structure | Input/keyboard | Result/actions |
|---|---|---|---|
| Currency Converter | Refresh/status strip → From card → swap → To card → rate/source timestamp | Numeric keypad only for amount; searchable currency picker shows only selected pair in the work surface (flag + ISO code + selected currency name) | Live pair conversion; rate date/provider/offline state; swap preserves amount and recalculates; refresh throttled; no country list rendered as keypad keys |
| Unit Converter | Category selector → From unit/value → swap → To unit/result → note/convert | Numeric keypad for value; unit selector is category-filtered searchable list; only selected unit label appears in field | Conversion uses category-specific factors; temperature uses offset formula; swap only within compatible category |
| Discount | Original price → discount percent → result summary | Numeric keypad; percent field accepts decimal only | Discount amount, final price, savings; invalid negative/out-of-range percent rejected |
| Percentage | Mode selector → only fields required by selected mode → calculate/result | Numeric keypad; +/- and percent action only where valid | Modes: percentage of value, value as percentage, percentage change; labels and validation change with mode |
| Sales Tax | Tax mode → amount → rate → tax summary | Numeric keypad | Before-tax/after-tax modes; subtotal, tax, total; currency symbol localized; no duplicate suffix/border |
| Loan / EMI | Principal → annual rate → tenure → payment frequency/method → summary → amortization | Numeric keypad; method/frequency select | EMI/payment, total interest, total paid; amortization table horizontally scrollable; invalid rate/term guarded |
| Savings | Initial amount → periodic contribution → rate → duration → compounding frequency | Numeric keypad; frequency selector | Future value, invested principal, interest earned; compounding assumptions visible |
| Tip | Bill amount → tip preset/custom → split count → tax preference | Numeric keypad; preset chips | Tip, total, per-person; custom selection exposes one editable percent field |
| Unit Price | Product A quantity/price → Product B quantity/price → normalized comparison | Numeric keypad; unit selector for matching quantity type | Cost per common unit and better-value result; compare only compatible units |
| Percentage Calculator | Two/three-field mode-dependent form | Numeric keypad | Exact mode semantics shown in the label and result; do not mix formula meanings |
| Grade Average | Subject rows (name/grade/weight) → add/remove → weighted result | Numeric keypad for grade/weight; text keyboard for subject name | Weighted/unweighted average according to selected mode; empty rows ignored only when clearly empty |
| Number Base / Hex | Base selector/representation → value editor → converted output for BIN/OCT/DEC/HEX | Base-aware keypad; disable digits invalid in active base; A–F only where allowed | Exact integer conversion; sign/range validation; copy result; no decimal keyboard when base forbids decimal |
| Scientific | Separate display, function bank, memory row and 5×4 keypad | Scientific keypad and physical keyboard; SHIFT state | See section 4; unsupported advanced engines remain hidden |
| Body Metrics | Measurement system → height/weight/age → optional sex input only for formula requiring it | Numeric keypad; selector for unit/system | BMI and any included metric separately labelled; no health diagnosis or misleading status color |
| Date | Start/end date → date difference; event name/date/repeat controls | Native date picker + text keyboard; no numeric keypad overlay for date fields | UTC-safe calendar-day difference, reverse-range policy clear; event list supports add/edit/delete/repeat |
| Fuel Cost | Distance → fuel efficiency/consumption → fuel price → calculate | Numeric keypad | Estimated fuel used and cost; unit consistency (km/L vs L/100km) explicit |
| Fuel Efficiency | Before/after fuel level → added fuel → distance | Numeric keypad | Consumption/efficiency result with neutral incomplete state; unit shown beside value |
| World Time | Search city/time zone → selected city cards → add/remove/reorder | Search keyboard; native time-zone list | Live local times and date offsets; DST-safe IANA zone IDs; no guessed city offsets |

## 6. Currency and Unit picker rules
- The keypad is numeric only; never render all currency country names or unit names among digit keys.
- Current selection displays only the selected currency/unit. Picker opens separately as a searchable, scrollable list with one row per option.
- Currency rows: flag (where known), ISO 4217 code, localized currency name; search by country, code or name. Do not imply that every currency has a unique country.
- Unit rows: unit name + symbol; list filtered to current category. Category change resets invalid From/To selections to valid defaults and recalculates.
- Pair/category change preserves entered amount where meaningful; clear stale result while the new conversion is resolving.

## 7. History
- Newest first; expression and result are separate lines; timestamp/name optional and visually secondary.
- Actions: restore expression to correct calculator, copy result, share, rename, protect/unprotect, delete one row.
- Clear operation removes only unprotected rows and confirms before destructive bulk action. Protected entries are never silently evicted by the normal cap.
- Empty state has a single helpful message; loading/error states do not masquerade as empty history.
- History recording preference applies to Basic and Scientific uniformly, or is explicitly labelled per calculator if storage engines differ.

## 8. Favorites
- User-selected tools only; preserve order; remove through a clear star/pin action.
- Empty state directs to Tools or Settings → Favorites Management.
- Favorite card geometry matches Tools cards; tapping opens the exact tool and returns to Favorites on Back.

## 9. Settings — complete section order
1. **Appearance:** full-screen, font size, keep screen awake.
2. **Theme & Colors:** appearance mode, theme/accent picker, OLED true black.
3. **Calculator Settings:** live result preview, implicit multiplication, calculator-specific angle mode where relevant.
4. **Decimal & Number Format:** precision, thousands separator, trailing zeros.
5. **Language:** app language and RTL layout verification.
6. **Startup Preferences:** launch destination, restore previous values.
7. **Favorites Management:** tool checklist, reset defaults.
8. **History Settings:** record history, max entries, clear unlocked history.
9. **Clipboard & Copy:** auto-copy results.
10. **Sound & Vibration:** key sounds, haptics, intensity.
11. **Privacy:** local storage explanation, clear app data/cache confirmation.
12. **About & Support:** version, help, feedback/bug report, reset defaults.

Settings layout: group title 11–12sp uppercase with 18dp top separation; card radius 16dp; row min-height 56–60dp; label 13sp, description 11–12sp; switch aligned end; select control 44–48dp and max ~48% row width. Long labels wrap; controls never overlap. Destructive rows are visually distinct and require confirmation. Changes persist immediately and show feedback only when appropriate. Reset restores all defaults with explicit confirmation and does not silently erase history unless the user chooses that action.

## 10. Dialogs, pickers, menus and feedback
- Modal width: min(available width − 32dp, 480dp); height max 80% viewport; internal content scroll; fixed action footer.
- One modal at a time; focus trap, initial focus, Escape/back closes topmost layer, focus returns to opener.
- Toast anchored above the active keypad/navigation and never covers the last key or result. Use live region; short duration; no blocking alert for routine feedback.
- More/overflow only contains actions relevant to the current screen; no duplicate actions already visible.

## 11. Theme and localization
- Every theme must define background, surface, elevated surface, primary text, secondary text, border, focus, primary action, destructive, success and disabled colors.
- No theme may make menu/settings icons, labels, hints, selected states or secondary legends invisible. Check contrast in dark, light, OLED and accent variants.
- RTL mirrors content and directional icons, but mathematical expressions remain LTR. Currency/unit code and numeric strings retain correct bidi isolation.
- Font scaling must wrap labels and scroll rather than clip or shrink touch targets.

## 12. Performance, data and reliability
- Keep calculation engines pure and synchronous for small expressions; debounce only expensive live previews, never delay key echo.
- Delegate repeated DOM work; avoid layout reads in rapid input loops; animate transform/opacity only; honor reduced motion.
- Persist settings/history/memory with schema versioning and malformed-data recovery. Storage failure must not crash calculation.
- Currency rate refresh is network-dependent, timestamped, throttled and cached; never present stale rate as live. Offline status must be explicit.
- Date arithmetic uses calendar dates/UTC-safe comparisons; World Time uses IANA zones and DST rules.
- All controls have labels, focus states, disabled states and keyboard accessibility. No touch target below 48dp unless its hit area is safely expanded without overlap.

## 13. Regression and device test matrix
- Width: 320, 360, 393, 430, 600, 840dp; height: compact <480, medium 480–899, expanded ≥900dp.
- Orientation: portrait + landscape; Android system font scale 1.0/1.3/1.5; dark/light/OLED; all accent themes; English/Hindi/Arabic/Chinese.
- Navigation: every top tab; every tool open/back; system Back; dialog/picker/keypad Back; preserve input and focus.
- Calculator: precedence, unary signs, percent, repeat equals, long expressions, divide-by-zero, precision boundaries, caret/delete, keyboard parity.
- Scientific: all primary/secondary mappings, SHIFT consume/reset, DEG/RAD, memory isolation, ANS, history restore, More, long expression overflow and domain errors.
- Tools: empty/incomplete/valid/invalid values; unit/category swap; currency offline/provider fallback; all date edge cases; loan schedule scroll; base-valid digit gating.
- Settings: every switch/select, persistence after reload, reset, history retention, theme contrast and locale.
- Release: npm test, JS syntax, YAML parse, build:web, bundle required-assets, ZIP integrity, hosted Gradle APK identity, real-device screenshots/touch/performance.

## 14. Explicit limitations and release gates
This source package contains the 17 tool cards listed above plus Basic Calculator, Settings, Favorites and History. It does not contain a validated symbolic algebra engine, complex-number engine, matrix engine, integral/derivative solver, graph plotter, or full programmer base-N engine. Do not expose those as functional until implemented and tested. Source-level automated tests do not prove physical-device performance, rendering sharpness or APK installation; hosted Android build and real-device QA are mandatory release gates.
