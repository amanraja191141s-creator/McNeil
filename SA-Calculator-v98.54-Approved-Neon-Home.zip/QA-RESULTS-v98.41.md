# SA Calculator v98.41 QA results

## Source audit
- Inspected the supplied v98.40 ZIP (167 source/archive files) and the exact screenshot dimensions/layout.
- Confirmed 18 registered app destinations: Calculator, 16 tool destinations, and Settings.
- Confirmed the actual markup classes for calculator readout and actual IDs for bottom navigation.
- Identified layered legacy CSS and a closed-drawer visibility/focus leak risk that the prior v98.40 report did not fully address.
- Ran the unmodified v98.40 baseline suite before changes: 286 passed, 0 failed.

## v98.41 changes
- Added final DOM-targeted CSS for drawer visibility, calculator readout, keypad vertical sizing, bottom navigation sizing and converter keypad utility keys.
- Preserved keyboard skip navigation and TalkBack labels.
- Added 7 new source-level regression tests for actual markup selectors and bundle propagation.
- Added a 22-app competitive benchmark report and a clearly labeled 18-screen visual reference image.
- Bumped package, manifest, runtime, service-worker cache and Android workflow identity to 1.98.41-v98.41 / versionCode 1098041.

## Validation
- Automated tests: 293 passed, 0 failed.
- JavaScript syntax checks: passed.
- Android web bundle regeneration: passed; 19 required assets copied/verified.
- YAML parse: passed for canonical workflow and active GitHub Actions workflow.
- ZIP integrity: checked after packaging.

## Not claimed as complete
- Hosted GitHub Actions APK build was not run from this environment.
- Physical Android installation, screenshot comparison on the user's phone, touch latency, battery/long-session and device-specific WebView testing remain pending.
- The 18-screen image is a design reference collage, not a screenshot captured from a running APK.
