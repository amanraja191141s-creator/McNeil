# v98.48 — Screen-recording layout and behavior fixes

- Fixed Scientific Calculator vertical overflow: function grid is independently scrollable while all five numeric rows and memory controls remain in the visible workspace.
- Fixed scientific expression editor caret/scroll reset caused by assigning the same input value on every input event.
- Added horizontal expression visibility and bounded type sizing for long formulas.
- Forced Tools to a stable two-column grid; search/category rows no longer overlap tool cards.
- Normalized tool-card width, icon track, name wrapping and compact-screen behavior.
- Improved currency rate-note readability without changing conversion calculations or provider behavior.
- Preserved basic calculator engine, independent scientific state, all existing tool destinations, and navigation IDs.
