# SA Calculator v98.54 — Approved Neon Home

This release replaces the previous Home presentation with the supplied Neon Blue SA Calculator reference. The prior v98.53 Home CSS layer is removed from the active stylesheet chain, not merely overridden.

## Home replacement
- Reference-matched app bar: hamburger, crisp operator-symbol SA Calculator logo, app title, history and overflow actions.
- Borderless navy display with a custom scalable blue wave asset; expression and result remain visible together after evaluation.
- Four-column, five-row keypad with dark numeric keys, neon-blue AC/operators/equal, and a two-column zero key.
- Five-destination bottom navigation with SVG icons and cyan active indicator/glow.
- Responsive compact/short-height/landscape rules and Android-safe touch targets.

## Preserved behavior
Existing `data-calc` keypad hooks, calculation engine, expression input, result preview, history, drawer, settings, favorites, Tools routing, and child-tool navigation handlers are retained. Header and navigation controls keep their existing event IDs.

## Build and test
- `npm run build:web` — consolidates 18 CSS source layers and prepares the Capacitor `www` bundle.
- `npm test` — 340 automated tests pass in the current source verification.
- The included `.github/workflows/main.yml` and `SA-Calculator-v98.54-Android-Workflow.yml` verify the exact package identity and build a debug APK on GitHub Actions.

## Release identity
- Package: `1.98.54-v98.54`
- Android versionCode: `1098054`
- Offline cache: `sa-calculator-v98-54-approved-neon-home-v9854`

## Validation boundary
Local source tests, CSS parsing, YAML parsing and Android web-bundle generation pass. The hosted Gradle/APK build and physical Android installation, screenshot comparison, touch and performance tests still need to run; no device-level bug-free or lag-free claim is made before those checks.
