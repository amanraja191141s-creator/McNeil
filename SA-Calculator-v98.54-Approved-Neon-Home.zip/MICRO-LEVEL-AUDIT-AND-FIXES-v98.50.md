# v98.50 Micro-Level Scientific Calculator Reference Polish

## Reference mapping
The two supplied reference screenshots were used as visual references for:
- A large, high-contrast expression/result display with a compact DEG/RAD and memory status strip.
- A six-column scientific function bank, with small secondary legends above supported primary functions.
- A six-control editing strip (SHIFT, angle mode, caret movement, delete and clear).
- A dedicated memory row and a five-column, four-row numeric/operator keypad.
- A charcoal calculator chassis, beveled graphite keys, gold secondary legends and a pale green display panel.
- A compact four-column basic calculator keypad with slightly reduced visual weight.

## Behavior retained and verified in source
- SHIFT continues to switch supported inverse-trigonometric and logarithmic/exponential mappings.
- DRG continues to toggle DEG/RAD and persist the selected angle mode.
- Caret navigation, delete, clear, sign toggle, ANS, memory, history and More remain wired to existing handlers.
- No fake matrix, complex-number, symbolic algebra, derivative, integral or graphing actions were added. These require real calculation engines and independent numerical validation.
- Basic calculator key visual refinement does not scale the button hitbox; minimum 48 CSS px is retained.

## Engineering changes
- Added `assets/css/rebuild-v98.50.css` as the final cascade layer.
- Added explicit `data-sci-hint` legends to all 18 currently supported primary scientific function keys.
- Refined scientific display, key bevels, function legends, toolbar, memory row and numeric keypad proportions.
- Refined basic keypad spacing and surface weight without transforming hit areas.
- Bumped release identity to `1.98.50-v98.50` and Android versionCode to `1098050`.
- Updated service-worker cache namespace and workflow exact-source checks.
- Added focused v98.50 regression tests.

## Validation boundary
Automated source tests, JS syntax, YAML syntax, ZIP integrity and web-bundle checks are required before release. A hosted Android SDK build and real-device screenshots/touch testing remain separate validation steps; they cannot be truthfully claimed from source-only tests.
