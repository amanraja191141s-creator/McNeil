import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v98.54 approved neon Home replaces the previous Home CSS layer',()=>{
 const html=read('index.html'), builder=read('scripts/prepare-android-web.mjs');
 const pkg=JSON.parse(read('package.json')), manifest=JSON.parse(read('manifest.webmanifest'));
 assert.equal(pkg.version,'1.98.54-v98.54'); assert.equal(manifest.version,pkg.version);
 assert.match(html,/sa-build-version" content="1\.98\.54-v98\.54/);
 assert.match(html,/rebuild-v98\.54\.css/); assert.doesNotMatch(html,/rebuild-v98\.53\.css/);
 assert.match(builder,/rebuild-v98\.54\.css/); assert.doesNotMatch(builder,/rebuild-v98\.53\.css/);
 assert.ok(fs.existsSync(path.join(root,'assets/brand/sa-home-neon-wave.svg')));
 assert.ok(fs.existsSync(path.join(root,'assets/brand/sa-calculator-home-logo.svg')));
});
test('reference Home header exposes menu, logo, history and overflow actions',()=>{
 const html=read('index.html');
 for(const id of ['btn-drawer-open','btn-header-history','btn-tools-more']) assert.ok(html.includes(`id="${id}"`));
 assert.match(html,/class="brand-mark"[\s\S]*?class="header-title" id="app-title"/);
 assert.match(html,/sa-calculator-home-logo\.svg/);
 assert.match(html,/btn-header-history[\s\S]*?<svg/);
});
test('Home display keeps expression and result visible together on equals',()=>{
 const css=read('assets/css/rebuild-v98.54.css');
 assert.match(css,/\.calc-display\.result-mode \.calc-expression-row\{display:flex!important/);
 assert.match(css,/\.calc-display\s*\{[\s\S]*?border:0!important/);
 assert.match(css,/sa-home-neon-wave\.svg/);
});
test('Home keypad preserves all calculation handlers and exact 4x5 reference grid',()=>{
 const html=read('index.html'), css=read('assets/css/rebuild-v98.54.css');
 const home=html.match(/<div class="screen active" id="screen-calc">([\s\S]*?)<\/div>\s*<section class="screen scientific-screen"/)[1];
 for(const key of ['C','±','%','/','7','8','9','*','4','5','6','-','1','2','3','+','0','.','=']) assert.ok(home.includes(`data-calc="${key}"`),`missing key ${key}`);
 assert.match(home,/class="key-btn zero-key" data-calc="0"/);
 assert.match(css,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
 assert.match(css,/grid-template-rows:repeat\(5,minmax\(48px,1fr\)\)!important/);
 assert.match(css,/min-width:48px!important;min-height:48px!important/);
});
test('five-tab navigation has reference icons, glow and accessible hidden state',()=>{
 const html=read('index.html'), css=read('assets/css/rebuild-v98.54.css');
 const nav=html.match(/<nav class="bottom-navigation"[\s\S]*?<\/nav>/)?.[0]||'';
 assert.equal((nav.match(/data-bottom-nav=/g)||[]).length,5);
 for(const item of ['calc','history','favorites','tools','settings']) assert.ok(nav.includes(`data-bottom-nav="${item}"`));
 assert.match(nav,/<svg/); assert.match(css,/bottom-nav-item\.active::before/);
 assert.match(css,/bottom-navigation\.bottom-navigation\[hidden\]\{display:none!important\}/);
});
test('Android web build and offline cache include the approved wave asset and v98.54 identity',()=>{
 const sw=read('service-worker.js'), wf=read('.github/workflows/main.yml');
 assert.match(sw,/sa-calculator-v98-54-approved-neon-home-v9854/);
 assert.match(sw,/sa-home-neon-wave\.svg/); assert.match(sw,/sa-calculator-home-logo\.svg/);
 assert.match(wf,/1\.98\.54-v98\.54/); assert.match(wf,/1098054/);
 assert.match(wf,/assets\/brand\/sa-home-neon-wave\.svg/); assert.match(wf,/assets\/brand\/sa-calculator-home-logo\.svg/);
});
