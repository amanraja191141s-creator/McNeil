'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ROOT = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(ROOT, 'assets/js/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'assets/css/rebuild-v98.32.css'), 'utf8');

test('currency catalogue has 105 unique supported ISO codes with explicit names', () => {
  const match = app.match(/const CURRENCY_CATALOG = (\[[^;]+\]);/);
  assert.ok(match, 'currency catalogue is missing');
  const codes = JSON.parse(match[1].replace(/'/g, '"'));
  assert.equal(codes.length, 105);
  assert.equal(new Set(codes).size, 105);
  const namesBlock = app.match(/const CURRENCY_DISPLAY_NAMES = \{([\s\S]*?)\n\};/);
  assert.ok(namesBlock);
  for (const code of codes) assert.match(namesBlock[1], new RegExp(`\\"${code}\\"\\s*:`));
});

test('one unified searchable currency picker renders flags, localized names, ISO codes and one close action', () => {
  assert.doesNotMatch(html, /id="currency-picker-modal"/);
  assert.doesNotMatch(app, /function openCurrencyPicker\(/);
  assert.match(app, /const searchableCurrency = \/\^cur-\(from\|to\)\$\//);
  assert.match(app, /currencyFlagForCode\(code\)/);
  assert.match(app, /localizedCurrencyName\(code\)/);
  assert.match(app, /currencyRegionNameForCode\(code\)/);
  assert.match(app, /sumaire-picker-option-flag/);
  assert.match(app, /Search currency name, code or country/);
  assert.match(app, /sumaire-picker-close/);
  assert.doesNotMatch(app, /sumaire-picker-cancel|sumaire-picker-footer/);
  assert.match(css, /\.sumaire-picker-option-flag/);
  assert.match(css, /\.sumaire-picker-search/);
});
