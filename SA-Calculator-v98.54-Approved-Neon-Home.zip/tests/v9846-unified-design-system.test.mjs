import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('v98.46 unified design layer defines coherent dark and light palettes and a shared shape scale', () => {
  const css = read('assets/css/rebuild-v98.46.css') + read('assets/css/rebuild-v98.47.css');
  for (const token of ['--sa-radius-xs','--sa-radius-sm','--sa-radius-md','--sa-radius-lg','--sa-radius-xl','--sa-control-height']) assert.ok(css.includes(token), `missing ${token}`);
  assert.match(css, /html\[data-theme="dark"\], body\[data-theme="dark"\]/);
  assert.match(css, /html\[data-theme="light"\], body\[data-theme="light"\]/);
  assert.match(css, /--primary-blue:\s*#168bff/);
  assert.match(css, /--primary-blue:\s*#0878e8/);
});

test('shared tool cards, fields, navigation and calculator display receive consistent shapes', () => {
  const css = read('assets/css/rebuild-v98.46.css') + read('assets/css/rebuild-v98.47.css');
  assert.match(css, /\.calc-card[\s\S]*?border-radius:\s*var\(--sa-radius-lg\)/);
  assert.match(css, /#screen-viewport input[\s\S]*?border-radius:\s*var\(--sa-radius-sm\)/);
  assert.match(css, /\.bottom-nav-item\.active/);
  assert.match(css, /#screen-calc > \.calc-display[\s\S]*?border:\s*0 !important/);
});

test('Tools cards have fixed premium dimensions and compact-screen fallbacks', () => {
  const css = read('assets/css/rebuild-v98.46.css') + read('assets/css/rebuild-v98.47.css');
  assert.match(css, /min-height:\s*78px !important/);
  assert.match(css, /width:\s*42px !important/);
  assert.match(css, /@media\s*\(max-width:\s*360px\)/);
  assert.match(css, /grid-template-columns:\s*repeat\(2, minmax\(0, 1fr\)\)/);
});

test('v98.46 stylesheet is required, built, cached and release identity synchronized', () => {
  const html = read('index.html');
  const builder = read('scripts/prepare-android-web.mjs');
  const workflow = read('.github/workflows/main.yml');
  const sw = read('service-worker.js');
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  assert.match(html, /rebuild-v98\.46\.css/);
  assert.match(builder, /rebuild-v98\.46\.css/);
  assert.match(workflow, /assets\/css\/rebuild-v98\.46\.css/);
  assert.match(workflow, /assets\/css\/rebuild-v98\.47\.css/);
  assert.match(sw, /sa-calculator-v98-54-approved-neon-home-v9854/);
  assert.equal(pkg.version, '1.98.54-v98.54');
  assert.equal(manifest.version, pkg.version);
  assert.match(workflow, /1098054/);
});

test('existing tool destinations and calculation handlers remain in source', () => {
  const html = read('index.html');
  const app = read('assets/js/app.js');
  const start = html.indexOf('id="premium-tools-grid"');
  const end = html.indexOf('</div>', start);
  const ids = [...html.slice(start, end).matchAll(/data-tool-screen="([a-z]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, 17);
  assert.equal(new Set(ids).size, 17);
  for (const id of ids.filter(x => x !== 'scientific')) assert.ok(html.includes(`id="screen-${id}"`), `screen missing: ${id}`);
  assert.match(app, /function calculate|const calculate|calculateTool|calculateResult/);
});
